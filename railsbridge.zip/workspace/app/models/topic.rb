class Topic < ActiveRecord::Base
end
