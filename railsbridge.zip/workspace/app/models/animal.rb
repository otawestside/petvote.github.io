class Animal < ActiveRecord::Base
end
